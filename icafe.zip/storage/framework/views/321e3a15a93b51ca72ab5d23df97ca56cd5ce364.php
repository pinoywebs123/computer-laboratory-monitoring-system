<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Norsu Icafe Admin</title>

    
    <link href="<?php echo e(URL::to('admin/css/bootstrap.min.css')); ?>" rel="stylesheet">

   
    <link href="<?php echo e(URL::to('admin/css/sb-admin.css')); ?>" rel="stylesheet">

   
    <link href="<?php echo e(URL::to('admin/css/plugins/morris.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(URL::to('admin/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

    <style type="text/css">
        .input-group{
            margin-bottom: 10px;
        }
    </style>   
</head>

<body>

    <div id="wrapper">

       
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
           
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#" data-toggle="modal" data-target="#test">NORSU Admin</a>
            </div>
            
            <ul class="nav navbar-right top-nav">
               
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo e(Auth::user()->f_name); ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                       
                        
                        <li>
                            <a href="<?php echo e(route('admin_settings')); ?>"><i class="fa fa-fw fa-gear"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="<?php echo e(route('logout')); ?>"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
           
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <center>
                        <img src="<?php echo e(URL::to('asset/images/admin.png')); ?>" height="80px" width="80px">
                    </center>
                    <li>
                       <a href="#">
                            <p class="text-center" style="color: #fff"><?php echo e(Auth::user()->l_name); ?>, <?php echo e(Auth::user()->f_name); ?> <?php echo e(Auth::user()->m_name); ?></p>
                            <p class="text-center" style="color: #fff">Online</p>
                       
                       </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin')); ?>"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
                     <li>
                        <a href="<?php echo e(route('admin_staff')); ?>"><i class="fa fa-fw fa-dashboard"></i> Staff</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin-student')); ?>"><i class="fa fa-fw fa-dashboard"></i> Student</a>
                    </li>
                    <li class="active">
                        <a href="<?php echo e(route('admin-pc')); ?>"><i class="fa fa-fw fa-dashboard"></i> PC</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin_report')); ?>"><i class="fa fa-fw fa-dashboard"></i> Reports</a>
                    </li>
                    
                </ul>
            </div>
           
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

               
                <div class="row">
                    <div class="col-lg-12">
                       <h1>Pc's</h1>
                        <button class="btn btn-primary" data-toggle="modal" data-target="#addPc">Add</button>
                        <?php if(Session::has('added')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('added')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('info')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(Session::get('info')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
               

                <div class="row">
                    <div class="col-lg-8">
                      
                       <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h1>CAS 5 Operation</h1>
                            </div>
                            <div class="panel-body">
                                <table class="table">
                                   <thead>
                                        <tr>
                                            <th>PC</th>
                                            <th>Last Name</th>
                                            <th>First Name</th>
                                            <th>Dept</th>
                                            <th>Year</th>
                                            <th>Staff</th>
                                            <th>Start</th>
                                        </tr>  
                                   </thead>  
                                   <tbody>
                                       <?php if($logs->count()): ?>
                                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <?php if($log->staff->role_id == 2): ?>
                                        <tr>
                                             <td><?php echo e($log->computer->pc_no); ?></td>
                                            <td><?php echo e($log->student->lname); ?></td>
                                            <td><?php echo e($log->student->fname); ?></td>
                                            <td><?php echo e($log->student->college); ?></td>
                                            <td><?php echo e($log->student->year); ?></td>
                                            <td>
                                                <?php echo e($log->staff->l_name); ?>,<?php echo e($log->staff->f_name); ?>

                                            </td>
                                            <td><?php echo e($log->created_at->diffForHumans()); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <?php endif; ?>  
                                   </tbody>
                                   
                                </table>
                            </div>
                       </div>

                       <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h1>CAS 7 Operation</h1>
                            </div>
                            <div class="panel-body">
                                <table class="table">
                                   <thead>
                                        <tr>
                                            <th>PC</th>
                                            <th>Last Name</th>
                                            <th>First Name</th>
                                            
                                            <th>Dept</th>
                                            <th>Year</th>
                                            
                                            <th>Staff</th>
                                            <th>Start</th>
                                        </tr>  
                                   </thead>  
                                   <tbody>
                                       <?php if($logs->count()): ?>
                                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <?php if($log->staff->role_id == 3): ?>
                                        <tr>
                                             <td><?php echo e($log->computer->pc_no); ?></td>
                                            <td><?php echo e($log->student->lname); ?></td>
                                            <td><?php echo e($log->student->fname); ?></td>
                                            
                                            <td><?php echo e($log->student->college); ?></td>
                                            <td><?php echo e($log->student->year); ?></td>
                                           
                                            <td>
                                                <?php echo e($log->staff->l_name); ?>,<?php echo e($log->staff->f_name); ?>

                                            </td>
                                            <td><?php echo e($log->created_at->diffForHumans()); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <?php endif; ?>  
                                   </tbody>
                                   
                                </table>
                            </div>
                       </div>

                       <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h1>CAS 8 Operation</h1>
                            </div>
                            <div class="panel-body">
                                <table class="table">
                                   <thead>
                                        <tr>
                                            <th>PC</th>
                                            <th>Last Name</th>
                                            <th>First Name</th>
                                            <th>Dept</th>
                                            <th>Year</th>
                                            <th>Staff</th>
                                            <th>Start</th>
                                        </tr>  
                                   </thead>  
                                   <tbody>
                                        <?php if($logs->count()): ?>
                                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <?php if($log->staff->role_id == 4): ?>
                                        <tr>
                                            <td><?php echo e($log->computer->pc_no); ?></td>
                                            <td><?php echo e($log->student->lname); ?></td>
                                            <td><?php echo e($log->student->fname); ?></td>
                                            <td><?php echo e($log->student->college); ?></td>
                                            <td><?php echo e($log->student->year); ?></td>
                                            <td>
                                                <?php echo e($log->staff->l_name); ?>,<?php echo e($log->staff->f_name); ?>

                                            </td>
                                            <td><?php echo e($log->created_at->diffForHumans()); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <?php endif; ?>  
                                   </tbody>
                                   
                                </table>
                            </div>
                       </div>

                    </div>

                    <div class="col-lg-4">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1>CAS 5 PC</h1>
                            </div>
                            <div class="panel-body">
                                <table class="table">
                                    <head>
                                        <tr>
                                            <th>No.</th>
                                            <th>Room</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </head>
                              
                                <tbody>
                                      <?php $__currentLoopData = $pcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                      <?php if($pc->room == 2): ?>
                                        <tr>
                                            <td><a href="#"><?php echo e($pc->pc_no); ?></a></td>
                                            <td>cas5</td>
                                            <td>
                                                <?php 
                                                    if($pc->status == 0){
                                                        echo 'avilable';
                                                    }else{
                                                        echo'used';
                                                    }
                                                ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin_pc_edit',['pc_id'=> $pc->id, 'room'=> $pc->room])); ?>" class="btn btn-info btn-xs"><i class="glyphicon glyphicon-pencil"></i></a>
                                                <a href="<?php echo e(route('pc_delete', ['pc_id'=> $pc->id, 'room'=> $pc->room])); ?>" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i></a>
                                            </td>
                                            
                                        </tr>
                                        <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                   </tbody> 
                                   
                                </table>  
                            </div>
                       </div>
                       <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1>CAS 7 PC</h1>
                            </div>
                            <div class="panel-body">
                                <table class="table">
                                    <head>
                                        <tr>
                                            <th>No.</th>
                                            <th>Room</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </head>
                              
                                <tbody>
                                       <?php $__currentLoopData = $pcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                      <?php if($pc->room == 3): ?>
                                        <tr>
                                            <td><a href="#"><?php echo e($pc->pc_no); ?></a></td>
                                            <td>cas7</td>
                                            <td>
                                                <?php 
                                                    if($pc->status == 0){
                                                        echo 'avilable';
                                                    }else{
                                                        echo'used';
                                                    }
                                                ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin_pc_edit',['pc_id'=> $pc->id, 'room'=> $pc->room])); ?>" class="btn btn-info btn-xs"><i class="glyphicon glyphicon-pencil"></i></a>
                                                <a href="<?php echo e(route('pc_delete', ['pc_id'=> $pc->id, 'room'=> $pc->room])); ?>" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i></a>
                                            </td>
                                            
                                        </tr>
                                        <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                   </tbody> 
                                   
                                </table>  
                            </div>
                       </div>
                       <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1>CAS 8 PC</h1>
                            </div>
                            <div class="panel-body">
                                <table class="table">
                                    <head>
                                        <tr>
                                            <th>No.</th>
                                            <th>Room</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </head>
                              
                                <tbody>
                                       <?php $__currentLoopData = $pcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                      <?php if($pc->room == 4): ?>
                                        <tr>
                                            <td><a href="#"><?php echo e($pc->pc_no); ?></a></td>
                                            <td>cas8</td>
                                            <td>
                                                <?php 
                                                    if($pc->status == 0){
                                                        echo 'avilable';
                                                    }else{
                                                        echo'used';
                                                    }
                                                ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin_pc_edit',['pc_id'=> $pc->id, 'room'=> $pc->room])); ?>" class="btn btn-info btn-xs"><i class="glyphicon glyphicon-pencil"></i></a>
                                                <a href="<?php echo e(route('pc_delete', ['pc_id'=> $pc->id, 'room'=> $pc->room])); ?>" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i></a>
                                            </td>
                                            
                                        </tr>
                                        <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                   </tbody> 
                                   
                                </table>  
                            </div>
                       </div>
                    </div>
                </div>
                
               

               

               
                    
                    

            </div>
           

        </div>
       
        <div class="modal fade" id="addPc">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-head">
                         <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                               <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                               </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-body">
                        <h3>PC Information</h3>
                        <form action="<?php echo e(route('addPc')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="input-group">
                                <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                                <input type="text" name="pc" class="form-control" placeholder="PC No." required="">
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                                <select name="room" class="form-control" required="">
                                    <option value="0">Room</option>
                                    <option value="2">5</option>
                                    <option value="3">7</option>
                                    <option value="4">8</option>
                                </select>
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                                <input type="text" name="cpu" class="form-control" placeholder="CPU" required="">
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                                <input type="text" name="motherboard" class="form-control" placeholder="Motherboard" required="">
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                                <input type="text" name="ram" class="form-control" placeholder="RAM" required="">
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                                <input type="text" name="hdd" class="form-control" placeholder="HDD" required="">
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                                <input type="text" name="keyboard" class="form-control" placeholder="Keyboard" required="">
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                                <input type="text" name="mouse" class="form-control" placeholder="Mouse" required="">
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
   

   
    <script src="<?php echo e(URL::to('admin/js/jquery.js')); ?>"></script>

    
    <script src="<?php echo e(URL::to('admin/js/bootstrap.min.js')); ?>"></script>

    
    <script src="<?php echo e(URL::to('admin/js/plugins/morris/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('admin/js/plugins/morris/morris.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('admin/js/plugins/morris/morris-data.js')); ?>"></script>

</body>

</html>
