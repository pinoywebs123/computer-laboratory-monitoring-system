<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Norsu Icafe Attendant</title>

    
    <link href="<?php echo e(URL::to('admin/css/bootstrap.min.css')); ?>" rel="stylesheet">

   
    <link href="<?php echo e(URL::to('admin/css/sb-admin.css')); ?>" rel="stylesheet">

   
    <link href="<?php echo e(URL::to('admin/css/plugins/morris.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(URL::to('admin/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

   <script>
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    "Time " + h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
</script>
</head>

<body onload="startTime()">

    <div id="wrapper">

       
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
           
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#" data-toggle="modal" data-target="#test">NORSU Staff</a>
            </div>
            
            <ul class="nav navbar-right top-nav">
               
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo e(Auth::user()->f_name); ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                       
                        <li>
                            <a href="<?php echo e(route('settings')); ?>"><i class="fa fa-fw fa-gear"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="<?php echo e(route('logout')); ?>"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
           
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                	<center>
                		<img src="<?php echo e(URL::to('asset/images/admin.png')); ?>" height="80px" width="80px">
                	</center>
                    <li>
                       <a href="#">
                       		<p class="text-center" style="color: #fff"><?php echo e(Auth::user()->l_name); ?>, <?php echo e(Auth::user()->f_name); ?> <?php echo e(Auth::user()->m_name); ?></p>
                       		<p class="text-center" style="color: #fff">Online</p>
                       
                       </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('staff')); ?>"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
                     <li>
                        <a href="<?php echo e(route('staff_login')); ?>"><i class="fa fa-fw fa-dashboard"></i> LogIn</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('staff_logout')); ?>"><i class="fa fa-fw fa-dashboard"></i> LogOut</a>
                    </li>
                    
                   
                    <li>
                        <a href="<?php echo e(route('check_balance')); ?>"><i class="fa fa-fw fa-dashboard"></i> Check Balance</a>
                    </li>

                    <li  class="active">
                        <a href="<?php echo e(route('staff_report')); ?>"><i class="fa fa-fw fa-dashboard"></i> Reports</a>
                    </li>
                    
                    
                </ul>
            </div>
           
        </nav>

        <div id="page-wrapper">
            <div>
                <h2>Staff Reports</h2>
            </div>
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 id="print_head">List of Reports</h3>
                    <button type="button" id="print" class="btn btn-info btn-xs">Print</button>
                </div>
                <div class="panel-body">
                    
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Dept</th>
                                <th>Room</th>
                                <th>PC</th>
                                <th>LastName</th>
                                <th>FirstName</th>
                                <th>MiddleName</th>
                                <th>Start time</th>
                                <th>End time</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($reports->count()): ?>
                                    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                       <?php if($report->staff->role_id == $role->role_id): ?>
                                            <tr>
                                               <td><?php echo e($report->student->college); ?></td>
                                               <td><?php echo e($report->staff->role->name); ?></td>
                                               <td><?php echo e($report->computer_id); ?></td>
                                                <td><?php echo e($report->student->lname); ?></td>
                                                <td><?php echo e($report->student->fname); ?></td>
                                                <td><?php echo e($report->student->mname); ?></td>
                                                <td><?php echo e($report->start); ?></td>
                                                <td><?php echo e($report->end); ?></td>
                                                <td><?php echo e($report->created_at->toDayDateTimeString()); ?></td>
                                           </tr>
                                       <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        </div>
       

    </div>
   

   
    <script src="<?php echo e(URL::to('admin/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(URL::to('admin/js/bootstrap.min.js')); ?>"></script>
     <script type="text/javascript">
       $(document).ready(function(){
            $("#print").on('click', function(){
                $("#print_head").addClass("text-center");
                $("#print_head").text("Room <?php echo e(Auth::user()->role_id); ?> Daily Report");
                $("tbody").append("<p>by: <?php echo e(Auth::user()->l_name); ?></p>")
                window.print();
            });
       });
    </script>
    
    <script src="<?php echo e(URL::to('admin/js/plugins/morris/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('admin/js/plugins/morris/morris.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('admin/js/plugins/morris/morris-data.js')); ?>"></script>


</body>

</html>
