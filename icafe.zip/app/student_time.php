<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class student_time extends Model
{
    protected $fillable = ['time'];
}
